const selenium_webdriver_1 = require("selenium-webdriver");
async function main(){
    let count = 0;

    let driverCapabilities = {
        "goog:chromeOptions": {
            binary: "..\\node_modules\\electron\\dist\\electron.exe",
            args: ["app=electron", "log-level=debug"]
        }
    };
    // Create a new WebDriver Builder object.
    let driverBuilder = new selenium_webdriver_1.Builder();
    // Connect with ChromeDriver.
    driverBuilder = driverBuilder.usingServer("http://localhost:9515");
    // Drive the desired electron Binary.
    driverBuilder = driverBuilder.withCapabilities(driverCapabilities);
    driverBuilder = driverBuilder.forBrowser("chrome");
    // Start up the driver and the IDE instance.
    let driver = await driverBuilder.build();
    while(true){
       
        await driver.wait(
            // Look for the toolbar icon.
            selenium_webdriver_1.until.elementLocated(selenium_webdriver_1.By.id("textEditor.commands.go.back")),
            50000
        );
        // Refresh the IDE.
        await driver.navigate().refresh(); 

        count++;
        console.log(count);
    }
} main();

